// C++ program to create target string, starting from
// random string using Genetic Algorithm
#include<vector>
#include <iostream>
#include<string>
#include<cmath>
#include<algorithm>
#include <ctime>
#include "VariadicTable.h"
//#define M_PI 3.14.59265358979323846264338327950288
using namespace std;

//Change this to false if you want to test minimizing the function
bool isMax = true;
  
// Number of individuals in each generation
#define POPULATION_SIZE 100
#define MAX_GENERATIONS 100
// Valid Gene range.
const int MAX_SIZE = 75;
const float MUTATE_RATE = .05;
const float ELITE_PERCENT = 10;
  
// Function to generate random numbers in given range
int getRand(int end)
{
    return rand()%(end+1);
}
  
vector<float> createChromosome()
{
    vector<float> newGene;
    for(int i = 0;i<4;i++){
        newGene.push_back((rand() / (float)RAND_MAX * MAX_SIZE));
    }
    return newGene;
}
  
class Individual
{
public:
    vector<float> chromosome;
    float fitness;
    int number;
    int parent1 = -1;
    int parent2 =-1;
    Individual(vector<float> chromosome);
    vector<float> crossover(Individual parent2);
    void mutate();
    float computeFitness();
};
  
Individual::Individual(vector<float> chromosome)
{
    this->chromosome = chromosome;
    this->fitness = computeFitness();
};
  
void Individual::mutate(){
    float chance = getRand(100)/100.0;
    if(chance < MUTATE_RATE){
        chance = getRand(100)/100.0;
        if(chance < .25){
            chromosome.at(0) = (rand() / (float)RAND_MAX * MAX_SIZE);
        }
        else if(chance < .5){
            chromosome.at(1) = (rand() / (float)RAND_MAX * MAX_SIZE);
        }
        else if(chance < .75){
            chromosome.at(2) = (rand() / (float)RAND_MAX * MAX_SIZE);
        }
        else{
            chromosome.at(3) = (rand() / (float)RAND_MAX * MAX_SIZE);
        }
    }
}
vector<float> Individual::crossover(Individual par2)
{
    vector<float> child;
    
    for(int i = 0;i<4;i++)
    {
        float chance = getRand(100)/100.0;
        if(chance < 0.5)
            child.push_back(chromosome.at(i));
        else
            child.push_back(par2.chromosome.at(i));
    }
    return child;
};
  
float Individual::computeFitness()
{
    float omega = 2*M_PI;
    float w = chromosome.at(0);
    float x = chromosome.at(1);
    float y = chromosome.at(2);
    float z = chromosome.at(3);
    return (pow(sin(omega*(x+w)), 2))*(pow(sin(omega*(y+z)), 2))*(pow(2.71828,(-1*(w+x+y+z)/150)));
};
  
bool operator<(const Individual &one, const Individual &two)
{
    if(isMax)
        return one.fitness > two.fitness;
    else
        return one.fitness < two.fitness;
}

void printResults(vector<Individual> oldPop, int generation, vector<Individual> newPop){
    VariadicTable<string, string, float, int, int, string, string, string, float, int, int> t({"Num", "Chromosome  ", "Fitness     ", "Parent 1   ", "Parent 2  ", "@@@@", "Num", "Chromosome  ", "Fitness     ", "Parent 1   ", "Parent 2  "});
    cout << endl << "Generation: " << generation << "                                                                                             " << "Generation: " << generation +1 << endl;
    int count = 0;
    string countString;
    float min = 1000;
    float max = -1000;
    float average = 0;
    int bestIndividual = -90;
    for(Individual x: oldPop){
        if(newPop.at(count).fitness < min){
            min = newPop.at(count).fitness;
            if(!isMax){
                bestIndividual = count;
            }
        }
        if(newPop.at(count).fitness > max){
            max = newPop.at(count).fitness;
            if(isMax){
                bestIndividual = count;
            }
        }
        average += newPop.at(count).fitness;
        countString = to_string(count);
        countString.append(") ");
        string chromeString = "";
        chromeString.append(to_string(x.chromosome.at(0))).append(", ").append(to_string(x.chromosome.at(1))).append(", ").append(to_string(x.chromosome.at(2))).append(", ").append(to_string(x.chromosome.at(3)));
        string chromeString2 = "";
        chromeString2.append(to_string(newPop.at(count).chromosome.at(0))).append(", ").append(to_string(newPop.at(count).chromosome.at(1))).append(", ").append(to_string(newPop.at(count).chromosome.at(2))).append(", ").append(to_string(newPop.at(count).chromosome.at(3)));
        t.addRow({countString, chromeString, x.fitness, x.parent1, x.parent2, "@@@@", countString, chromeString2, newPop.at(count).fitness, newPop.at(count).parent1, newPop.at(count).parent2});
        count++;
    }
    t.print(std::cout);
        if(isMax){
            cout << "Note: Generation " << generation + 1 << " & Accumulated Statistics: max=" << max << ", min=" << min << ", avg=" << average/count << ", sum=" << average << " Best Individual to date is " << bestIndividual << " fitness: " << newPop.at(bestIndividual).fitness << endl;
        }
}

vector<int> getElites(){
        vector<int> elites;
        int count = (ELITE_PERCENT*POPULATION_SIZE)/100;
        int i = 0;
        while(i < count){
            int randomIndex = rand() % POPULATION_SIZE;
            if (!(std::find(elites.begin(), elites.end(), randomIndex) != elites.end())){
                    elites.push_back(randomIndex);
                    i++;
            }
        }
        return elites;
}
int main()
{
      int generation = 0;
      vector<Individual> population;
      //initialize population
      for(int i = 0;i<POPULATION_SIZE;i++)
      {
          vector<float> chomesomes = createChromosome();
          population.push_back(Individual(chomesomes));
      }
      //
      while(generation < MAX_GENERATIONS)
      {
          sort(population.begin(), population.end());
          vector<Individual> newPop;

          //eliteism for 10% of the population

        vector<int> eliteIndexs = getElites();
        for(auto x: eliteIndexs){
            population.at(x).parent1 = -10;
            population.at(x).parent2 = -10;
            newPop.push_back(population.at(x));
        }
          int count;
          count = (90*POPULATION_SIZE)/100;
          for(int i = 0;i<count;i++)
          {
              int r = getRand(POPULATION_SIZE/2);
              Individual parent1 = population[r];
              int r2 = getRand(POPULATION_SIZE/2);
              while(r2 == r){
                r2 = getRand(POPULATION_SIZE/2);
              }
              Individual parent2 = population[r2];
              Individual childOne = Individual(parent1.crossover(parent2));
              //Individual childTwo = Individual(parent1.crossover(parent2));
              childOne.mutate();
             // childTwo.mutate();
              childOne.parent1 = r;
              childOne.parent2 = r2;
              //childTwo.parent1 = r;
             // childTwo.parent2 = r2;
              newPop.push_back(childOne);
             // newPop.push_back(childTwo);
          }
          printResults(population, generation, newPop);
          population = newPop;
          generation++;
       }
}
